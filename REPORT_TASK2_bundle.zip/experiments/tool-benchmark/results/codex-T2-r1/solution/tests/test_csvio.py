import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from cartkit.csvio import load_orders


HEADER = 'order_id,sku,quantity,unit_price_cents\n'


class LoadOrdersTests(unittest.TestCase):
    def test_grouping_preserves_order_and_duplicate_skus(self):
        self.assertEqual(load_orders(HEADER + (
            'A1,BOOK,2,150\nB2,PEN,1,20\nA1,BOOK,3,100\n'
        )), [
            {'order_id': 'A1', 'lines': [
                {'sku': 'BOOK', 'quantity': 2, 'unit_price_cents': 150},
                {'sku': 'BOOK', 'quantity': 3, 'unit_price_cents': 100},
            ]},
            {'order_id': 'B2', 'lines': [
                {'sku': 'PEN', 'quantity': 1, 'unit_price_cents': 20},
            ]},
        ])

    def test_reordered_trimmed_headers_and_cells(self):
        self.assertEqual(load_orders(
            ' unit_price_cents , quantity , sku , order_id \n'
            ' 00150 , 00 , BOOK , A1 \n'
        ), [{'order_id': 'A1', 'lines': [
            {'sku': 'BOOK', 'quantity': 0, 'unit_price_cents': 150},
        ]}])

    def test_quoted_commas_newlines_and_escaped_quotes(self):
        self.assertEqual(load_orders(
            HEADER + '"A,1","a ""quoted""\r\nbook",2,150\r\n'
        ), [{'order_id': 'A,1', 'lines': [
            {'sku': 'a "quoted"\r\nbook', 'quantity': 2, 'unit_price_cents': 150},
        ]}])

    def test_blank_rows_and_header_only(self):
        self.assertEqual(load_orders(HEADER), [])
        self.assertEqual(load_orders('\n  \n' + HEADER + '\n , , , \n'), [])
        self.assertEqual(load_orders(HEADER + '\nA1,BOOK,0,0\n\n'), [
            {'order_id': 'A1', 'lines': [
                {'sku': 'BOOK', 'quantity': 0, 'unit_price_cents': 0},
            ]},
        ])

    def test_invalid_headers(self):
        for header in ('', '\n', 'order_id,sku,quantity',
                       'order_id,sku,quantity,quantity',
                       'order_id,sku,quantity,unit_price_cents,extra',
                       'order_id,sku,quantity,price',
                       'order_id,sku, quantity ,quantity'):
            with self.subTest(header=header), self.assertRaises(ValueError):
                load_orders(header)

    def test_invalid_row_width_and_identifiers(self):
        for row in ('A1,BOOK,2', 'A1,BOOK,2,150,extra',
                    'A1,BOOK,2,150,', ' ,BOOK,2,150', 'A1, ,2,150'):
            with self.subTest(row=row), self.assertRaises(ValueError):
                load_orders(HEADER + row)

    def test_numeric_fields_require_ascii_digits(self):
        for field in (2, 3):
            for value in ('', '-1', '+1', '1.0', 'True', 'false',
                          '١', '１２', '²', '1 2', '1e2'):
                row = ['A1', 'BOOK', '2', '150']
                row[field] = value
                with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                    load_orders(HEADER + ','.join(row))

    def test_malformed_csv_raises_value_error(self):
        for row in ('A1,"BOOK,2,150', 'A1,"BOOK"x,2,150'):
            with self.subTest(row=row), self.assertRaises(ValueError):
                load_orders(HEADER + row)


class CliTests(unittest.TestCase):
    def run_cli(self, command, text):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'input'
            path.write_bytes(text.encode('utf-8'))
            result = subprocess.run(
                [sys.executable, '-m', 'cartkit.cli', command, str(path)],
                capture_output=True, text=True, check=True,
                cwd=Path(__file__).resolve().parents[1],
            )
        return json.loads(result.stdout)

    def test_import_csv(self):
        self.assertEqual(self.run_cli(
            'import-csv', HEADER + 'A1,"BOOK,\nPEN",2,150\n'
        ), [{'order_id': 'A1', 'lines': [
            {'sku': 'BOOK,\nPEN', 'quantity': 2, 'unit_price_cents': 150},
        ]}])

    def test_existing_commands(self):
        self.assertEqual(self.run_cli(
            'totals', '[{"unit_price_cents": 150, "quantity": 2}]'
        )['total_cents'], 300)
        self.assertEqual(self.run_cli('summary', '[]'), {
            'paid_count': 0, 'paid_total_cents': 0,
            'cancelled_count': 0, 'customers': {},
        })


if __name__ == '__main__':
    unittest.main()
